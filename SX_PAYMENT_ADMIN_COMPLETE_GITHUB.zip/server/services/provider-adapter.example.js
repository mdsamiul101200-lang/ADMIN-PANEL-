/*
  PROVIDER ADAPTER BOUNDARY

  The following names correspond to the provider operations supplied
  during project planning. They are intentionally left as adapter
  placeholders rather than live financial transaction executors.

  - C2CRechargeConfirm
  - CreateRechargeOrder
  - C2CRecharge
  - C2CRechargeGetOrderDetail
  - C2CRechargeGetPayingDetail
  - ArUpiSubmitUtr
  - UpdateRechargesUpiOrder
  - UpdateRechargesUsdtOrder
  - UpRechargesBankOrder

  For a legitimate payment system, implement authentication,
  authorization, audit logging, idempotency, validation, database
  persistence, and provider-specific compliance controls here.
*/
module.exports = {
  C2CRechargeConfirm: async () => {
    throw new Error("Provider transaction execution is not enabled in this starter.");
  },
  CreateRechargeOrder: async () => {
    throw new Error("Provider transaction execution is not enabled in this starter.");
  },
  C2CRecharge: async () => {
    throw new Error("Provider transaction execution is not enabled in this starter.");
  },
  C2CRechargeGetOrderDetail: async () => {
    throw new Error("Provider transaction execution is not enabled in this starter.");
  },
  C2CRechargeGetPayingDetail: async () => {
    throw new Error("Provider transaction execution is not enabled in this starter.");
  },
  ArUpiSubmitUtr: async () => {
    throw new Error("Provider transaction execution is not enabled in this starter.");
  },
  UpdateRechargesUpiOrder: async () => {
    throw new Error("Provider transaction execution is not enabled in this starter.");
  },
  UpdateRechargesUsdtOrder: async () => {
    throw new Error("Provider transaction execution is not enabled in this starter.");
  },
  UpRechargesBankOrder: async () => {
    throw new Error("Provider transaction execution is not enabled in this starter.");
  }
};
