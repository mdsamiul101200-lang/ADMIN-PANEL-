const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 10000;

app.disable("x-powered-by");
app.use(helmet({
  contentSecurityPolicy: false
}));
app.use(express.json({ limit: "1mb" }));

const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 120,
  standardHeaders: true,
  legacyHeaders: false
});

app.use("/api/", apiLimiter);

app.get("/api/health", (req, res) => {
  res.json({
    ok: true,
    service: "SX Payment Admin",
    status: "online",
    time: new Date().toISOString()
  });
});

app.get("/api/config-status", (req, res) => {
  res.json({
    providerConfigured: Boolean(process.env.PROVIDER_API_BASE_URL),
    databaseConfigured: Boolean(process.env.DATABASE_URL),
    adminSecretConfigured: Boolean(process.env.ADMIN_AUTH_SECRET)
  });
});

/*
  IMPORTANT:
  This starter intentionally does not execute live wagering/payment
  confirmations, cancellations, withdrawals, or third-party financial
  transactions. The provider adapter is a safe integration boundary.
*/
app.use(express.static(path.join(__dirname, "public")));

app.get("*splat", (req, res) => {
  if (req.path.startsWith("/api/")) {
    return res.status(404).json({ error: "API route not found" });
  }
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`SX Payment Admin running on port ${PORT}`);
});
