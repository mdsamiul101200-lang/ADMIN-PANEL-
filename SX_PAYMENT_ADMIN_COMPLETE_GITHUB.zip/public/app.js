const navItems = document.querySelectorAll(".nav-item");
const sections = document.querySelectorAll(".section");
const pageTitle = document.getElementById("pageTitle");

navItems.forEach(btn => {
  btn.addEventListener("click", () => {
    const section = btn.dataset.section;
    navItems.forEach(x => x.classList.remove("active"));
    btn.classList.add("active");
    sections.forEach(x => x.classList.toggle("active", x.id === section));
    pageTitle.textContent = btn.textContent;
  });
});

function showToast(message) {
  const toast = document.getElementById("toast");
  toast.textContent = message;
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 2600);
}

async function loadStatus() {
  try {
    const health = await fetch("/api/health").then(r => r.json());
    document.getElementById("serverStatus").textContent = health.ok ? "● Online" : "Offline";

    const cfg = await fetch("/api/config-status").then(r => r.json());
    document.getElementById("providerState").textContent = cfg.providerConfigured ? "Configured" : "Not configured";
    document.getElementById("databaseState").textContent = cfg.databaseConfigured ? "Configured" : "Not configured";
    document.getElementById("authState").textContent = cfg.adminSecretConfigured ? "Configured" : "Not configured";
  } catch {
    document.getElementById("serverStatus").textContent = "Backend unavailable";
    showToast("Backend connection failed.");
  }
}

loadStatus();
