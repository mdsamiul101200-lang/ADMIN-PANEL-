# SX PAYMENT ADMIN

Professional mobile-friendly payment/order administration dashboard foundation.

## Included

- Express backend
- Premium responsive admin UI
- Dashboard / Orders / Transactions / Audit Log / Settings
- Health endpoint
- Render configuration
- Environment template
- GitHub ZIP extraction workflow
- Provider adapter boundary

## GitHub ZIP workflow

Workflow path:

`.github/workflows/unzip-project.yml`

The workflow extracts a ZIP from the repository root, copies the project files into the repository, removes the ZIP, commits the result and pushes it.

### Important GitHub limitation

GitHub does not execute a workflow merely because the workflow YAML is sitting inside a ZIP file. For a completely empty repository, the workflow itself must be bootstrapped into `.github/workflows/` once. After that, the ZIP workflow can be used normally.

## Render

After extraction, connect the repository to Render.

Build command:

`npm install`

Start command:

`npm start`

Health check:

`/api/health`

## Provider integration

The supplied provider endpoints are documented in:

`server/services/provider-adapter.example.js`

This starter intentionally does not execute live wagering/payment confirmation, cancellation, withdrawal, or other third-party financial actions.
